#{{uc_id}} {
  position: {% if relative_to == 'section' %} sticky {% else %} fixed {% endif %};
  inset: 0;
  width: 100%;
  height: 100%;
  max-height: 100vh;
  pointer-events: none;
}

{% if relative_to == 'page' %}
  .elementor-section>.elementor-container {
      z-index: 2;
  }
{% endif %}