( () => {
  	
    const canvas = document.querySelector('#{{uc_id}}')
     
    function initSmoker(canvas){
      // canvas.parentElement.style.zIndex = 1
      {% if relative_to == 'page' %}

        //canvas.closest('.elementor-section').style.zIndex = 1
          canvas.parentElement.parentElement.style.zIndex = 1
      {% endif %}

      const fluidOptions = {
        TRIGGER: 'hover',
        IMMEDIATE: {{draw_on_load}},
        SPLAT_RADIUS: {{size_nounit}},
        BLOOM: {{enable_bloom}},
        SUNRAYS: {{enable_sunrays}},
        COLORFUL: {% if color_type == 'colorful' %} true {% else %} false {% endif %},
        CUSTOM_COLOR: {% if color_type == 'custom' %} true {% else %} false {% endif %},
        COLOR: '{{color}}',
        TEXTURE: '{{uc_assets_url}}img/dithering_texture.png'
      }

      const options = {
        canvas: canvas,
        eventsContainer: {% if relative_to == 'section' %} canvas.parentElement.parentElement {% else %} window {% endif %},
        fluidOptions: fluidOptions
      }

      import('{{uc_assets_url}}js/ue_webgl_fluid.js')
        .then( module => {
          new module.UeWebglFluid(options)
        })
        .catch( error => { console.log('unable to load UeWebglFluid', error) })
   } 
   
   if(canvas == null){
     setTimeout(function(){
       const canvas = document.querySelector('#{{uc_id}}')
       initSmoker(canvas);
     },300);
   }else{
     initSmoker(canvas);
   }                                                                        
                                                       
                                                        
})();