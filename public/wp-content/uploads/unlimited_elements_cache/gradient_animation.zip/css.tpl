#{{uc_id}} {
	background: linear-gradient({{angle_nounit}}deg, {{color_one}}, {{color_two}}, {{color_three}}, {{color_four}});
	background-size: 400% 400%;
	animation: {{uc_id}}gradient {{duration}}s ease infinite;
	position:absolute;
	top:0px;
	left:0px;
	bottom:0px;
	right:0px;
}

@keyframes {{uc_id}}gradient {
	0% {
		background-position: 0% 50%;
	}
	50% {
		background-position: 100% 50%;
	}
	100% {
		background-position: 0% 50%;
	}
}