{{ ucfunc("put_docready_start") }}
		
  var objWidget = jQuery("#{{uc_id}}");
  var objParent = objWidget.parent();
  var dataLocation = objParent.data("location");
 
  //fix for bg location
  function initFixForBgLocation(){
    var objWidget = jQuery("#{{uc_id}}");
    var objParent = objWidget.parent();
    
    if(!objParent || objParent.length == 0)
      return(false);
    
    {% if uc_inside_editor == "no" %}
    var dataLocation = objParent.data("location");
   
    if(!dataLocation || dataLocation != "back")
      return(false);
    {% endif %} 
    
    var objMainHolder = objParent.parent();
     
    if(!objMainHolder || objMainHolder.length == 0)
      return(false);
    
    //adjust z-index for UE bg overlay    
    objParent.css("z-index", 1);
    
    //adjust z-index for Elementor MAin Container where both overlay are located
    var initialZIndex = objMainHolder.css("--z-index");
    
    if(!initialZIndex || initialZIndex == "" || initialZIndex == "revert" || initialZIndex < 1 || initialZIndex == "auto")
      objMainHolder.css("--z-index", 1);
  }

  //init fix
  initFixForBgLocation();
    	
{{ ucfunc("put_docready_end") }}