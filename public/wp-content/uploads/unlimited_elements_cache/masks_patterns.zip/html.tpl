<div id="{{uc_id}}">
  {% if apply_pattern == 'true' %}
    <div class="ue_background_pattern"></div>
  {% endif %}
  {% if apply_mask == 'true' %}
    <div class="ue_background_mask"></div>
  {% endif %}
</div>